
package eps;

import java.awt.Color;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;


public class PantallaEPS extends javax.swing.JFrame {
    
    String nombre ;
    String apellido;
    int edad, uTurno = 0, callout = 5, window;
    boolean condicion = false, afiliacion = false, delete;
    
    
    Usuario user;
    Timer tempo = new Timer(); 
    Llamado run = new Llamado();
    
    Queue<Usuario> ingresados = new LinkedList<>();
    
    DefaultListModel<String> software = new DefaultListModel<String>();
    

    public PantallaEPS() {
        
        initComponents();
        software= new DefaultListModel();
        lista.setModel(software);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelLlamado = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        turno = new javax.swing.JLabel();
        paciente = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        inLastName = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        inEdad = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        inCondition = new javax.swing.JToggleButton();
        jLabel9 = new javax.swing.JLabel();
        pos = new javax.swing.JButton();
        pc = new javax.swing.JButton();
        name = new javax.swing.JTextField();
        ninguno = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        lista = new javax.swing.JList<>();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setAutoRequestFocus(false);
        setBackground(new java.awt.Color(153, 153, 153));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        panelLlamado.setBackground(new java.awt.Color(0, 204, 204));
        panelLlamado.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        panelLlamado.setToolTipText("");

        jLabel1.setFont(new java.awt.Font("Myanmar Text", 1, 14)); // NOI18N
        jLabel1.setText("LLAMADO DE PACIENTES");

        jLabel2.setFont(new java.awt.Font("Myanmar Text", 1, 11)); // NOI18N
        jLabel2.setText("TURNO: ");

        jLabel3.setFont(new java.awt.Font("Myanmar Text", 1, 11)); // NOI18N
        jLabel3.setText("PACIENTE: ");

        turno.setFont(new java.awt.Font("Myanmar Text", 1, 14)); // NOI18N

        paciente.setFont(new java.awt.Font("Myanmar Text", 1, 14)); // NOI18N

        javax.swing.GroupLayout panelLlamadoLayout = new javax.swing.GroupLayout(panelLlamado);
        panelLlamado.setLayout(panelLlamadoLayout);
        panelLlamadoLayout.setHorizontalGroup(
            panelLlamadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelLlamadoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelLlamadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panelLlamadoLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel1))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelLlamadoLayout.createSequentialGroup()
                        .addGroup(panelLlamadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(turno, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(panelLlamadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addGroup(panelLlamadoLayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(paciente, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(28, 28, 28))
        );
        panelLlamadoLayout.setVerticalGroup(
            panelLlamadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelLlamadoLayout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelLlamadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelLlamadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(paciente, javax.swing.GroupLayout.DEFAULT_SIZE, 15, Short.MAX_VALUE)
                    .addComponent(turno, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));

        jLabel4.setBackground(new java.awt.Color(102, 153, 255));
        jLabel4.setFont(new java.awt.Font("Myanmar Text", 1, 14)); // NOI18N
        jLabel4.setText("REGISTRO DE TURNOS");
        jLabel4.setOpaque(true);

        jLabel5.setFont(new java.awt.Font("Myanmar Text", 1, 11)); // NOI18N
        jLabel5.setText("NOMBRE: ");

        jLabel6.setFont(new java.awt.Font("Myanmar Text", 1, 11)); // NOI18N
        jLabel6.setText("APELLIDO:");

        inLastName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inLastNameActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Myanmar Text", 1, 11)); // NOI18N
        jButton1.setText("PEDIR TURNO");
        jButton1.setRequestFocusEnabled(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Myanmar Text", 1, 11)); // NOI18N
        jButton2.setText("ELIMINAR DATOS");
        jButton2.setRequestFocusEnabled(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Myanmar Text", 1, 11)); // NOI18N
        jLabel7.setText("EDAD:");

        inEdad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inEdadActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Myanmar Text", 1, 11)); // NOI18N
        jLabel8.setText("¿PRESENTA ESTADO DE EMBARAZO O LIMITACIÓN MOTRÍZ?");

        inCondition.setText("NO");
        inCondition.setFocusPainted(false);
        inCondition.setFocusable(false);
        inCondition.setInheritsPopupMenu(true);
        inCondition.setRequestFocusEnabled(false);
        inCondition.setRolloverEnabled(false);
        inCondition.setVerifyInputWhenFocusTarget(false);
        inCondition.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inConditionActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Myanmar Text", 1, 11)); // NOI18N
        jLabel9.setText("¿A QUÉ PLAN HACE PARTE?");

        pos.setFont(new java.awt.Font("Myanmar Text", 1, 11)); // NOI18N
        pos.setText("POS");
        pos.setRequestFocusEnabled(false);
        pos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                posActionPerformed(evt);
            }
        });

        pc.setFont(new java.awt.Font("Myanmar Text", 1, 11)); // NOI18N
        pc.setText("PC");
        pc.setRequestFocusEnabled(false);
        pc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pcActionPerformed(evt);
            }
        });

        name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameActionPerformed(evt);
            }
        });

        ninguno.setFont(new java.awt.Font("Myanmar Text", 1, 11)); // NOI18N
        ninguno.setText("NINGUNO");
        ninguno.setRequestFocusEnabled(false);
        ninguno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ningunoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(inCondition))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton2))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(28, 28, 28)
                                .addComponent(inLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel9))
                        .addContainerGap(18, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(pos)
                        .addGap(18, 18, 18)
                        .addComponent(pc)
                        .addGap(18, 18, 18)
                        .addComponent(ninguno)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(inEdad, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(48, 48, 48)
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel7)))
                        .addGap(57, 57, 57))
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inLastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(inEdad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(pos)
                    .addComponent(pc)
                    .addComponent(ninguno))
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(inCondition))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addGap(37, 37, 37))
        );

        jButton3.setFont(new java.awt.Font("Myanmar Text", 1, 11)); // NOI18N
        jButton3.setText("MÁS TIEMPO PARA EL PACIENTE");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        lista.setBackground(new java.awt.Color(0, 153, 255));
        jScrollPane1.setViewportView(lista);

        jLabel10.setBackground(new java.awt.Color(0, 153, 204));
        jLabel10.setFont(new java.awt.Font("Myanmar Text", 1, 18)); // NOI18N
        jLabel10.setText("LINEA DE ESPERA");
        jLabel10.setOpaque(true);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                .addComponent(panelLlamado, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(jLabel10)))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelLlamado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void inConditionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inConditionActionPerformed
         
        if (inCondition.isSelected()) {
             
             inCondition.setText("SI");
             condicion = true;
             System.out.println("ES VERDAD");
            
        }else{
             
             inCondition.setText("NO");
             condicion = false;
             System.out.println("ES FALSO");

        }
    }//GEN-LAST:event_inConditionActionPerformed

    private void inLastNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inLastNameActionPerformed

        apellido = inLastName.getText();

    }//GEN-LAST:event_inLastNameActionPerformed

    private void inEdadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inEdadActionPerformed
        
        edad = Integer.parseInt(inEdad.getText());
        
    }//GEN-LAST:event_inEdadActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        uTurno ++; 
        System.out.println("------ " + name.getText() + ", " + inEdad.getText());
        user = new Usuario(name.getText(), apellido, afiliacion, Integer.parseInt(inEdad.getText()), uTurno, condicion);

        System.out.println("test:"+ user.getNombre() +" "+ Integer.toString(user.getEdad()) + " "+ user.getApellido() + " " + user.getAfiliacion()+ " " + user.getTurno() + " "+ user.isCondicion());
        
        if (user.getEdad() <= 12 || user.getEdad() >= 65 || afiliacion == true || condicion == true ) {
            
                ((LinkedList<Usuario>) ingresados).addFirst(user);
                software.add(0, uTurno + "------" + user.getNombre());
            
        }else {


            ingresados.add(user);
            software.addElement(uTurno + "------" +user.getNombre());
            
        }
        
        if (uTurno == 1) {
            tempo.schedule(run, 5000 , callout*1000);
        }
        
        name.setText(null);
        inLastName.setText(null);
        inEdad.setText(null);
        pc.setBackground(Color.white);
        pos.setBackground(Color.white);
        ninguno.setBackground(Color.white);

        
    }//GEN-LAST:event_jButton1ActionPerformed
    
    public class Llamado extends TimerTask {
        @Override
        public void run() {
            
            if (uTurno >= 3) {
                
                Usuario primerUsuario = ingresados.peek();
                String nombreU = primerUsuario.getNombre();
                int turnoU = primerUsuario.getTurno();
                
            
                paciente.setText(nombreU);

                int cTurno = user.getTurno();
                turno.setText(Integer.toString(turnoU));
                
                window = JOptionPane.showConfirmDialog(null, "TURNO: " + turnoU + " PACIENTE: " + nombreU );
                delete = (window == JOptionPane.YES_OPTION);

                if (delete) {
                    ingresados.remove();
                    software.remove(0);
                }
            }
        }
    }
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
       name.setText(null);
       inLastName.setText(null);
       inEdad.setText(null);
       
       ninguno.setBackground(Color.white);
       pos.setBackground(Color.white);
       pc.setBackground(Color.white);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void ningunoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ningunoActionPerformed

        ninguno.setBackground(Color.GREEN);      
        afiliacion = false; 
        
    }//GEN-LAST:event_ningunoActionPerformed

    private void posActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_posActionPerformed

        pos.setBackground(Color.GREEN);
        afiliacion = true; 
        
    }//GEN-LAST:event_posActionPerformed

    private void pcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pcActionPerformed

        pc.setBackground(Color.GREEN);
        afiliacion = true; 
        
    }//GEN-LAST:event_pcActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        
        callout = callout + 5;
        System.out.println("" + callout);
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameActionPerformed
        
        nombre = name.getText();

    }//GEN-LAST:event_nameActionPerformed

    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PantallaEPS().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JToggleButton inCondition;
    private javax.swing.JTextField inEdad;
    private javax.swing.JTextField inLastName;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<String> lista;
    private javax.swing.JTextField name;
    private javax.swing.JButton ninguno;
    private javax.swing.JLabel paciente;
    private javax.swing.JPanel panelLlamado;
    private javax.swing.JButton pc;
    private javax.swing.JButton pos;
    private javax.swing.JLabel turno;
    // End of variables declaration//GEN-END:variables
}
