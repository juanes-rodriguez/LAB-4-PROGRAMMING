
package eps;

public class Usuario {

    private String nombre, apellido;
    private int edad, turno = 0;
    private boolean condicion = false, afiliacion = false;
    
    public Usuario(String newNombre, String newApellido, boolean newAfiliacion, int newEdad, int newTurno, boolean newCondicion){
        
        nombre = newNombre;
        apellido = newApellido;
        afiliacion = newAfiliacion;
        edad = newEdad;
        turno = newTurno; 
        condicion = newCondicion;
        
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setAfiliacion(boolean afiliacion) {
        this.afiliacion = afiliacion;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setTurno(int turno) {
        this.turno = turno;
    }

    public void setCondicion(boolean condicion) {
        this.condicion = condicion;
    }


    
    //////////////////////////////////////////////////////////////////////////////////////

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public boolean getAfiliacion() {
        return afiliacion;
    }

    public boolean isCondicion() {
        return condicion;
    }
    
    public int getTurno() {
        return turno;
    }

    public int getEdad() {
        return edad;
    }
    
    
}
