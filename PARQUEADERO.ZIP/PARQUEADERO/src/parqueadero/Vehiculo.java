
package parqueadero;

public class Vehiculo {

    String placa, tipoVehiculo, hora;
    int numeroVehiculo; 
    float precio;
    
    public Vehiculo(String newPlaca, String newVehiculo, String newHora, int newNumero, float newPrecio ) {
        
        placa = newPlaca; 
        tipoVehiculo = newVehiculo; 
        hora = newHora; 
        numeroVehiculo = newNumero;
        precio = newPrecio;  
    }

    public String getPlaca() {
        return placa;
    }

    public String getTipoVehiculo() {
        return tipoVehiculo;
    }

    public String getHora() {
        return hora;
    }

    public int getNumeroVehiculo() {
        return numeroVehiculo;
    }
    
    public float getPrecio(){
        return precio; 
    }
 /////////////////////////////////////////////////////////////////////

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public void setTipoVehiculo(String tipoVehiculo) {
        this.tipoVehiculo = tipoVehiculo;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public void setNumeroVehiculo(int numeroVehiculo) {
        this.numeroVehiculo = numeroVehiculo;
    }
    
    public void setPrecio(float precio){
        this.precio = precio;
    }
    
    
    
}
